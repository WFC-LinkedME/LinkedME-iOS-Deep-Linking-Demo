//
//  LMInstallRequest.h
//  iOS-Deep-Linking-SDK
//
//  Created by han on 5/26/15.
//  Copyright (c) 2015 LM han. All rights reserved.
//

#import "LMOpenRequest.h"

@interface LMInstallRequest : LMOpenRequest

@end
