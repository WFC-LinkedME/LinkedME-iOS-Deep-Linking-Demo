//
//  Apis.h
//  Pods
//
//  Created by Bindx on 10/21/15.
//
//

#ifndef Apis_h
#define Apis_h



//sdk版本
#define SDKVER @"1.0.0"

static NSString *const HostIP =  @"";

//获取Uber估计价格
static NSString *const Uber_estimates = @"http://api.uber.com/v1/estimates/price";

#endif /* Apis_h */
